package ps2.restapi;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
class DisciplinaController {

	private List<Disciplina> disciplinas;

	public DisciplinaController() {
		this.disciplinas = new ArrayList<>();
        this.disciplinas.add(new Disciplina(1, "disciplina 1", "d1", "c1", 1));
        this.disciplinas.add(new Disciplina(2, "disciplina 2", "d2", "c1", 2));
        this.disciplinas.add(new Disciplina(3, "disciplina 3", "d3", "c1",3));
        this.disciplinas.add(new Disciplina(4, "disciplina 4", "d4", "c1", 4));
        this.disciplinas.add(new Disciplina(5, "disciplina 5", "d5", "c1", 5));
	}

	@GetMapping("/api/disciplinas")
	Iterable<Disciplina> getDisciplinas() {
		return this.disciplinas;
	}
	
	@GetMapping("/api/disciplina/{id}")
	Optional<Disciplina> getDisciplina(@PathVariable int id) {
		for (Disciplina d: disciplinas) {
			if (d.getId() == id) {
				return Optional.of(d);
			}
		}
		return Optional.empty();
	}
	
	@PostMapping("/api/disciplinas")
	Disciplina createDisciplina(@RequestBody Disciplina d) {
		int maxId = 1;
		for (Disciplina disc: disciplinas) {
			if (disc.getId() > maxId) {
				maxId = disc.getId();
			}
		}
		d.setId(maxId+1);
		disciplinas.add(d);
		return d;
	}
	
	@PutMapping("/api/Disciplinaes/{DisciplinaId}")
	Optional<Disciplina> updateDisciplina(@RequestBody Disciplina disciplinaRequest, @PathVariable int id) {
		Optional<Disciplina> opt = this.getDisciplina(id);
		if (opt.isPresent()) {
			Disciplina disciplina = opt.get();
            disciplina.setId(disciplinaRequest.getId());
            disciplina.setNome(disciplinaRequest.getNome());
            disciplina.setCurso(disciplinaRequest.getCurso());
            disciplina.setSemestre(disciplinaRequest.getSemestre());
            disciplina.setSigla(disciplinaRequest.getSigla());
		}

		return opt;				
	}	
	
	@DeleteMapping(value = "/api/disciplina/{id}")
	void deleteDisciplina(@PathVariable int id) {
		disciplinas.removeIf(d -> d.getId() == id);
	}		
}


